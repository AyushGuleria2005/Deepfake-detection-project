import os
import sys
import numpy as np

# ============================================================
# PROJECT PATH
# ============================================================

PROJECT_ROOT = os.path.dirname(
    os.path.dirname(
        os.path.abspath(__file__)
    )
)

sys.path.insert(0, PROJECT_ROOT)


# ============================================================
# IMPORTS
# ============================================================

import pandas as pd
import torch

from torch.utils.data import Dataset, DataLoader

from sklearn.model_selection import GroupShuffleSplit

from sklearn.metrics import (
    roc_auc_score,
    accuracy_score,
    balanced_accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    confusion_matrix,
)

from models.audio_cnn_gn import AudioCNNGroupNorm


# ============================================================
# CONFIG
# ============================================================

TRAIN_CSV = os.path.join(
    PROJECT_ROOT,
    "research",
    "experiments",
    "audio_generator_holdout_train.csv",
)

TEST_CSV = os.path.join(
    PROJECT_ROOT,
    "research",
    "experiments",
    "audio_generator_holdout_test.csv",
)

CHECKPOINT = os.path.join(
    PROJECT_ROOT,
    "outputs",
    "checkpoints",
    "audio_cnn_gn_best.pth",
)

OUTPUT_CSV = os.path.join(
    PROJECT_ROOT,
    "research",
    "experiments",
    "audio_robust_final_predictions.csv",
)

RANDOM_STATE = 42
VAL_SIZE = 0.20
BATCH_SIZE = 64


# ============================================================
# DEVICE
# ============================================================

device = torch.device(
    "cuda" if torch.cuda.is_available() else "cpu"
)

print("=" * 65)
print("ROBUST AUDIO FINAL EVALUATION - GROUPNORM")
print("=" * 65)

print(f"Device: {device}")

if torch.cuda.is_available():
    print(
        f"GPU: {torch.cuda.get_device_name(0)}"
    )


# ============================================================
# DATASET
# ============================================================

class AudioFeatureDataset(Dataset):

    def __init__(self, dataframe):
        self.df = dataframe.reset_index(drop=True)

    def __len__(self):
        return len(self.df)

    def __getitem__(self, idx):

        row = self.df.iloc[idx]

        feature_path = row["feature_path"]

        feature = np.load(
            feature_path
        ).astype(np.float32)

        # Must match training
        if feature.shape != (64, 512):
            raise ValueError(
                f"Invalid feature shape: "
                f"{feature.shape} "
                f"for {feature_path}"
            )

        # IMPORTANT:
        # EXACT same preprocessing used during training
        feature = np.clip(
            feature,
            -20,
            10
        )

        feature = torch.from_numpy(
            feature
        ).unsqueeze(0)

        label = torch.tensor(
            float(row["audio_label"]),
            dtype=torch.float32
        )

        return feature, label


# ============================================================
# LOAD CSVs
# ============================================================

train_df = pd.read_csv(
    TRAIN_CSV
)

test_df = pd.read_csv(
    TEST_CSV
)

print()
print(
    f"Training pool samples: "
    f"{len(train_df)}"
)

print(
    f"Final test samples: "
    f"{len(test_df)}"
)


# ============================================================
# DATA AUDIT
# ============================================================

print()
print("=" * 65)
print("DATA AUDIT")
print("=" * 65)


# Duplicate physical files

train_duplicates = (
    train_df["actual_path"]
    .duplicated()
    .sum()
)

test_duplicates = (
    test_df["actual_path"]
    .duplicated()
    .sum()
)

print(
    f"Train duplicate physical paths: "
    f"{train_duplicates}"
)

print(
    f"Test duplicate physical paths: "
    f"{test_duplicates}"
)


# Missing features

train_missing = (
    ~train_df["feature_path"]
    .apply(os.path.exists)
).sum()

test_missing = (
    ~test_df["feature_path"]
    .apply(os.path.exists)
).sum()

print(
    f"Missing train features: "
    f"{train_missing}"
)

print(
    f"Missing test features: "
    f"{test_missing}"
)


# ============================================================
# EXACT TRAINING-STYLE GROUP SPLIT
# ============================================================

gss = GroupShuffleSplit(
    n_splits=1,
    test_size=VAL_SIZE,
    random_state=RANDOM_STATE,
)

train_idx, val_idx = next(
    gss.split(
        train_df,
        y=train_df["audio_label"],
        groups=train_df["source"],
    )
)

robust_train_df = train_df.iloc[
    train_idx
].copy()

val_df = train_df.iloc[
    val_idx
].copy()


# ============================================================
# SOURCE DISJOINTNESS
# ============================================================

train_sources = set(
    robust_train_df["source"]
)

val_sources = set(
    val_df["source"]
)

test_sources = set(
    test_df["source"]
)


print()
print("=" * 65)
print("SOURCE DISJOINTNESS")
print("=" * 65)

print(
    f"Train sources: "
    f"{len(train_sources)}"
)

print(
    f"Validation sources: "
    f"{len(val_sources)}"
)

print(
    f"Test sources: "
    f"{len(test_sources)}"
)

print(
    f"Train/Val source overlap: "
    f"{len(train_sources & val_sources)}"
)

print(
    f"Train/Test source overlap: "
    f"{len(train_sources & test_sources)}"
)

print(
    f"Val/Test source overlap: "
    f"{len(val_sources & test_sources)}"
)


# ============================================================
# LABEL DISTRIBUTION
# ============================================================

print()
print("=" * 65)
print("LABEL DISTRIBUTION")
print("=" * 65)

print("Validation:")

print(
    val_df["audio_label"]
    .value_counts()
    .sort_index()
)

print()

print("Final test:")

print(
    test_df["audio_label"]
    .value_counts()
    .sort_index()
)


# ============================================================
# TEST METHODS
# ============================================================

print()
print("=" * 65)
print("TEST METHODS")
print("=" * 65)

print(
    test_df["method"]
    .value_counts()
)


rtvc_count = (
    test_df["method"]
    .astype(str)
    .str.lower()
    .eq("rtvc")
    .sum()
)

print()

print(
    f"RTVC test samples: "
    f"{rtvc_count}"
)


# ============================================================
# DATA LOADERS
# ============================================================

val_dataset = AudioFeatureDataset(
    val_df
)

test_dataset = AudioFeatureDataset(
    test_df
)

val_loader = DataLoader(
    val_dataset,
    batch_size=BATCH_SIZE,
    shuffle=False,
    num_workers=0,
    pin_memory=torch.cuda.is_available(),
)

test_loader = DataLoader(
    test_dataset,
    batch_size=BATCH_SIZE,
    shuffle=False,
    num_workers=0,
    pin_memory=torch.cuda.is_available(),
)


# ============================================================
# LOAD GROUPNORM MODEL
# ============================================================

print()
print("=" * 65)
print("LOADING GROUPNORM MODEL")
print("=" * 65)

model = AudioCNNGroupNorm().to(
    device
)


if not os.path.exists(CHECKPOINT):

    raise FileNotFoundError(
        f"Checkpoint not found:\n"
        f"{CHECKPOINT}"
    )


checkpoint = torch.load(
    CHECKPOINT,
    map_location=device
)


# ============================================================
# CHECKPOINT FORMAT
# ============================================================

if (
    isinstance(checkpoint, dict)
    and "model_state_dict" in checkpoint
):

    state_dict = checkpoint[
        "model_state_dict"
    ]

elif (
    isinstance(checkpoint, dict)
    and "state_dict" in checkpoint
):

    state_dict = checkpoint[
        "state_dict"
    ]

else:

    state_dict = checkpoint


# ============================================================
# LOAD PARAMETERS
# ============================================================

missing_keys, unexpected_keys = (
    model.load_state_dict(
        state_dict,
        strict=False
    )
)


print(
    f"Missing model keys: "
    f"{len(missing_keys)}"
)

print(
    f"Unexpected model keys: "
    f"{len(unexpected_keys)}"
)


if missing_keys:

    print(
        "Missing keys:"
    )

    for key in missing_keys:
        print(key)


if unexpected_keys:

    print(
        "Unexpected keys:"
    )

    for key in unexpected_keys:
        print(key)


model.eval()


# ============================================================
# CHECKPOINT INFORMATION
# ============================================================

if isinstance(checkpoint, dict):

    checkpoint_epoch = checkpoint.get(
        "epoch",
        "N/A"
    )

    checkpoint_val_auc = checkpoint.get(
        "val_auc",
        "N/A"
    )

else:

    checkpoint_epoch = "N/A"
    checkpoint_val_auc = "N/A"


print(
    f"Checkpoint epoch: "
    f"{checkpoint_epoch}"
)

print(
    f"Checkpoint Val AUC: "
    f"{checkpoint_val_auc}"
)


# ============================================================
# INFERENCE FUNCTION
# ============================================================

def predict(loader):

    all_probs = []
    all_labels = []

    with torch.no_grad():

        for features, labels in loader:

            features = features.to(
                device,
                non_blocking=True
            )

            logits = model(
                features
            )

            probs = torch.sigmoid(
                logits
            ).view(-1)

            all_probs.extend(
                probs.detach()
                .cpu()
                .numpy()
                .tolist()
            )

            all_labels.extend(
                labels.numpy()
                .tolist()
            )

    return (
        np.array(all_labels),
        np.array(all_probs)
    )


# ============================================================
# STEP 1
# VALIDATION
# ============================================================

print()
print("=" * 65)
print("STEP 1: VALIDATION THRESHOLD SELECTION")
print("=" * 65)


val_labels, val_probs = predict(
    val_loader
)


# ============================================================
# VALIDATION AUC
# ============================================================

val_auc = roc_auc_score(
    val_labels,
    val_probs
)

print(
    f"Validation ROC-AUC: "
    f"{val_auc:.4f}"
)


# ============================================================
# THRESHOLD SEARCH
# ============================================================

thresholds = np.arange(
    0.05,
    0.951,
    0.01
)

best_threshold = 0.50
best_balanced_accuracy = -1
best_f1 = -1


for threshold in thresholds:

    val_preds = (
        val_probs >= threshold
    ).astype(int)

    ba = balanced_accuracy_score(
        val_labels,
        val_preds
    )

    f1 = f1_score(
        val_labels,
        val_preds,
        zero_division=0
    )

    if (
        ba > best_balanced_accuracy
        or
        (
            np.isclose(
                ba,
                best_balanced_accuracy
            )
            and
            f1 > best_f1
        )
    ):

        best_threshold = float(
            threshold
        )

        best_balanced_accuracy = ba

        best_f1 = f1


print(
    f"Selected threshold: "
    f"{best_threshold:.2f}"
)

print(
    f"Validation Balanced Accuracy: "
    f"{best_balanced_accuracy:.4f}"
)

print(
    f"Validation F1: "
    f"{best_f1:.4f}"
)


# ============================================================
# VALIDATION PROBABILITY SUMMARY
# ============================================================

print()
print(
    "Validation probability range:"
)

print(
    f"Min: "
    f"{val_probs.min():.6f}"
)

print(
    f"Max: "
    f"{val_probs.max():.6f}"
)

print(
    f"Mean: "
    f"{val_probs.mean():.6f}"
)


# ============================================================
# STEP 2
# FINAL UNSEEN RTVC TEST
# ============================================================

print()
print("=" * 65)
print("STEP 2: FINAL UNSEEN RTVC TEST")
print("=" * 65)


test_labels, test_probs = predict(
    test_loader
)


test_preds = (
    test_probs >= best_threshold
).astype(int)


# ============================================================
# FINAL METRICS
# ============================================================

test_auc = roc_auc_score(
    test_labels,
    test_probs
)

test_accuracy = accuracy_score(
    test_labels,
    test_preds
)

test_balanced_accuracy = (
    balanced_accuracy_score(
        test_labels,
        test_preds
    )
)

test_precision = precision_score(
    test_labels,
    test_preds,
    zero_division=0
)

test_recall = recall_score(
    test_labels,
    test_preds,
    zero_division=0
)

test_f1 = f1_score(
    test_labels,
    test_preds,
    zero_division=0
)

cm = confusion_matrix(
    test_labels,
    test_preds
)


print()

print(
    f"Test ROC-AUC: "
    f"{test_auc:.4f}"
)

print(
    f"Threshold: "
    f"{best_threshold:.2f}"
)

print(
    f"Accuracy: "
    f"{test_accuracy:.4f}"
)

print(
    f"Balanced Accuracy: "
    f"{test_balanced_accuracy:.4f}"
)

print(
    f"Precision: "
    f"{test_precision:.4f}"
)

print(
    f"Recall: "
    f"{test_recall:.4f}"
)

print(
    f"F1: "
    f"{test_f1:.4f}"
)

print()

print(
    "Confusion Matrix:"
)

print(cm)


# ============================================================
# PROBABILITY SUMMARY
# ============================================================

print()
print("=" * 65)
print("TEST PROBABILITY SUMMARY")
print("=" * 65)


real_probs = test_probs[
    test_labels == 0
]

fake_probs = test_probs[
    test_labels == 1
]


print(
    f"Real mean probability: "
    f"{real_probs.mean():.6f}"
)

print(
    f"Real median probability: "
    f"{np.median(real_probs):.6f}"
)

print(
    f"Real min probability: "
    f"{real_probs.min():.6f}"
)

print(
    f"Real max probability: "
    f"{real_probs.max():.6f}"
)

print()

print(
    f"Fake mean probability: "
    f"{fake_probs.mean():.6f}"
)

print(
    f"Fake median probability: "
    f"{np.median(fake_probs):.6f}"
)

print(
    f"Fake min probability: "
    f"{fake_probs.min():.6f}"
)

print(
    f"Fake max probability: "
    f"{fake_probs.max():.6f}"
)


# ============================================================
# METHOD-WISE RESULTS
# ============================================================

print()
print("=" * 65)
print("METHOD-WISE TEST RESULTS")
print("=" * 65)


results = test_df.reset_index(
    drop=True
).copy()

results[
    "predicted_fake_probability"
] = test_probs

results[
    "predicted_label"
] = test_preds


for method, group in results.groupby(
    "method"
):

    positions = group.index.to_numpy()

    method_probs = test_probs[
        positions
    ]

    method_labels = test_labels[
        positions
    ]

    method_preds = test_preds[
        positions
    ]

    method_accuracy = accuracy_score(
        method_labels,
        method_preds
    )

    print()
    print(
        f"Method: {method}"
    )

    print(
        f"Samples: {len(group)}"
    )

    print(
        f"Accuracy: "
        f"{method_accuracy:.4f}"
    )

    print(
        f"Mean fake probability: "
        f"{method_probs.mean():.6f}"
    )


# ============================================================
# SAVE RESULTS
# ============================================================

results.to_csv(
    OUTPUT_CSV,
    index=False
)


print()
print("=" * 65)
print("PREDICTIONS SAVED")
print("=" * 65)

print(
    OUTPUT_CSV
)

print()
print("=" * 65)
print("FINAL EVALUATION COMPLETE")
print("=" * 65)