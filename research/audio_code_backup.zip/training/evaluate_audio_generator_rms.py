import os
import sys
import tempfile
import subprocess

import numpy as np
import pandas as pd
import torch
import librosa

from tqdm import tqdm

from torch.utils.data import Dataset, DataLoader
from sklearn.model_selection import GroupShuffleSplit
from sklearn.metrics import (
    roc_auc_score,
    accuracy_score,
    balanced_accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    confusion_matrix,
)

# ============================================================
# PROJECT PATH
# ============================================================

PROJECT_ROOT = os.path.dirname(
    os.path.dirname(os.path.abspath(__file__))
)

sys.path.insert(0, PROJECT_ROOT)

from models.audio_cnn_gn import AudioCNNGroupNorm


# ============================================================
# CONFIG
# ============================================================

TRAIN_CSV = os.path.join(
    PROJECT_ROOT,
    "research",
    "experiments",
    "audio_generator_holdout_train.csv",
)

TEST_CSV = os.path.join(
    PROJECT_ROOT,
    "research",
    "experiments",
    "audio_generator_holdout_test.csv",
)

CHECKPOINT = os.path.join(
    PROJECT_ROOT,
    "outputs",
    "checkpoints",
    "audio_cnn_gn_best.pth",
)

OUTPUT_CSV = os.path.join(
    PROJECT_ROOT,
    "research",
    "experiments",
    "audio_generator_holdout_raw_rms_gn_predictions.csv",
)

FFMPEG = "ffmpeg"

SAMPLE_RATE = 16000
N_MELS = 64
N_FFT = 1024
HOP_LENGTH = 256
FMIN = 20
FMAX = 8000
TARGET_FRAMES = 512

TARGET_RMS = 0.05

VAL_SIZE = 0.20
RANDOM_STATE = 42
BATCH_SIZE = 32


# ============================================================
# DEVICE
# ============================================================

device = torch.device(
    "cuda" if torch.cuda.is_available() else "cpu"
)

print("=" * 70)
print("RAW WAVEFORM RMS NORMALIZATION - GROUPNORM")
print("=" * 70)

print(f"Device: {device}")

if torch.cuda.is_available():
    print(
        f"GPU: {torch.cuda.get_device_name(0)}"
    )


# ============================================================
# LOAD DATA
# ============================================================

train_df = pd.read_csv(TRAIN_CSV)
test_df = pd.read_csv(TEST_CSV)

print()
print(f"Training pool: {len(train_df)}")
print(f"Final test: {len(test_df)}")


# ============================================================
# EXACT SOURCE SPLIT
# ============================================================

gss = GroupShuffleSplit(
    n_splits=1,
    test_size=VAL_SIZE,
    random_state=RANDOM_STATE,
)

train_idx, val_idx = next(
    gss.split(
        train_df,
        y=train_df["audio_label"],
        groups=train_df["source"],
    )
)

robust_train_df = train_df.iloc[train_idx].copy()
val_df = train_df.iloc[val_idx].copy()


# ============================================================
# SOURCE AUDIT
# ============================================================

train_sources = set(robust_train_df["source"])
val_sources = set(val_df["source"])
test_sources = set(test_df["source"])

print()
print("=" * 70)
print("SOURCE DISJOINTNESS")
print("=" * 70)

print(f"Train sources: {len(train_sources)}")
print(f"Validation sources: {len(val_sources)}")
print(f"Test sources: {len(test_sources)}")

print(
    "Train/Val overlap:",
    len(train_sources & val_sources)
)

print(
    "Train/Test overlap:",
    len(train_sources & test_sources)
)

print(
    "Val/Test overlap:",
    len(val_sources & test_sources)
)


# ============================================================
# AUDIO EXTRACTION
# ============================================================

def extract_audio(video_path, wav_path):

    command = [
        FFMPEG,
        "-y",
        "-i",
        video_path,
        "-vn",
        "-ac",
        "1",
        "-ar",
        str(SAMPLE_RATE),
        "-acodec",
        "pcm_s16le",
        wav_path,
    ]

    result = subprocess.run(
        command,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.PIPE,
        text=True,
    )

    if result.returncode != 0:
        raise RuntimeError(
            f"FFmpeg failed for:\n"
            f"{video_path}\n\n"
            f"{result.stderr[-1000:]}"
        )


# ============================================================
# RMS NORMALIZED FEATURE
# ============================================================

def make_rms_normalized_feature(video_path):

    with tempfile.NamedTemporaryFile(
        suffix=".wav",
        delete=False
    ) as tmp:

        wav_path = tmp.name

    try:

        extract_audio(
            video_path,
            wav_path
        )

        waveform, sr = librosa.load(
            wav_path,
            sr=SAMPLE_RATE,
            mono=True
        )

    finally:

        if os.path.exists(wav_path):
            os.remove(wav_path)

    if waveform is None or len(waveform) == 0:
        raise ValueError(
            f"Empty audio: {video_path}"
        )

    # --------------------------------------------------------
    # Remove DC offset
    # --------------------------------------------------------

    waveform = waveform.astype(
        np.float32
    )

    waveform = (
        waveform
        - np.mean(waveform)
    )

    # --------------------------------------------------------
    # RMS normalization
    # --------------------------------------------------------

    rms = np.sqrt(
        np.mean(
            waveform ** 2
        ) + 1e-12
    )

    if rms > 1e-8:

        waveform = (
            waveform
            * (TARGET_RMS / rms)
        )

    # --------------------------------------------------------
    # Log-mel spectrogram
    # --------------------------------------------------------

    mel = librosa.feature.melspectrogram(
        y=waveform,
        sr=sr,
        n_fft=N_FFT,
        hop_length=HOP_LENGTH,
        n_mels=N_MELS,
        fmin=FMIN,
        fmax=FMAX,
        power=2.0,
    )

    log_mel = librosa.power_to_db(
        mel,
        ref=np.max
    )

    log_mel = log_mel.astype(
        np.float32
    )

    # --------------------------------------------------------
    # Crop / pad to 512 frames
    # --------------------------------------------------------

    frames = log_mel.shape[1]

    if frames < TARGET_FRAMES:

        pad_width = (
            TARGET_FRAMES - frames
        )

        log_mel = np.pad(
            log_mel,
            (
                (0, 0),
                (0, pad_width)
            ),
            mode="constant",
            constant_values=0,
        )

    else:

        log_mel = log_mel[
            :,
            :TARGET_FRAMES
        ]

    # --------------------------------------------------------
    # EXACT TRAINING CLIP
    # --------------------------------------------------------

    log_mel = np.clip(
        log_mel,
        -20,
        10
    )

    return log_mel


# ============================================================
# DATASET
# ============================================================

class RMSAudioDataset(Dataset):

    def __init__(self, dataframe):

        self.df = dataframe.reset_index(
            drop=True
        )

    def __len__(self):

        return len(self.df)

    def __getitem__(self, idx):

        row = self.df.iloc[idx]

        path = row["actual_path"]

        feature = make_rms_normalized_feature(
            path
        )

        feature = torch.from_numpy(
            feature.copy()
        ).unsqueeze(0)

        label = torch.tensor(
            float(row["audio_label"]),
            dtype=torch.float32
        )

        return feature, label


# ============================================================
# MODEL
# ============================================================

print()
print("=" * 70)
print("LOADING GROUPNORM CHECKPOINT")
print("=" * 70)

model = AudioCNNGroupNorm().to(device)

if not os.path.exists(CHECKPOINT):

    raise FileNotFoundError(
        f"Checkpoint not found:\n{CHECKPOINT}"
    )

checkpoint = torch.load(
    CHECKPOINT,
    map_location=device
)

if (
    isinstance(checkpoint, dict)
    and "model_state_dict" in checkpoint
):

    state_dict = checkpoint[
        "model_state_dict"
    ]

elif (
    isinstance(checkpoint, dict)
    and "state_dict" in checkpoint
):

    state_dict = checkpoint[
        "state_dict"
    ]

else:

    state_dict = checkpoint


missing, unexpected = model.load_state_dict(
    state_dict,
    strict=False
)

print(
    f"Missing keys: {len(missing)}"
)

print(
    f"Unexpected keys: {len(unexpected)}"
)

model.eval()

print(
    "Checkpoint epoch:",
    checkpoint.get("epoch", "N/A")
)

print(
    "Checkpoint Val AUC:",
    checkpoint.get("val_auc", "N/A")
)


# ============================================================
# FEATURE PRECOMPUTATION WITH PROGRESS BAR
# ============================================================

def build_features(
    dataframe,
    description
):

    dataframe = dataframe.reset_index(
        drop=True
    )

    features = []
    labels = []
    valid_rows = []

    failures = 0

    progress = tqdm(
        range(len(dataframe)),
        desc=description,
        unit="file",
        dynamic_ncols=True,
    )

    for idx in progress:

        row = dataframe.iloc[idx]

        try:

            feature = (
                make_rms_normalized_feature(
                    row["actual_path"]
                )
            )

            features.append(
                feature
            )

            labels.append(
                float(row["audio_label"])
            )

            valid_rows.append(idx)

            progress.set_postfix(
                valid=len(features),
                failed=failures,
            )

        except Exception as e:

            failures += 1

            progress.set_postfix(
                valid=len(features),
                failed=failures,
            )

    if len(features) == 0:

        raise RuntimeError(
            f"No valid features generated "
            f"for {description}"
        )

    feature_array = np.stack(
        features
    ).astype(np.float32)

    label_array = np.asarray(
        labels,
        dtype=np.float32
    )

    valid_dataframe = dataframe.iloc[
        valid_rows
    ].reset_index(drop=True)

    return (
        valid_dataframe,
        feature_array,
        label_array
    )


# ============================================================
# PRECOMPUTE VALIDATION FEATURES
# ============================================================

print()
print("=" * 70)
print("BUILDING RMS-NORMALIZED VALIDATION FEATURES")
print("=" * 70)

(
    val_valid_df,
    val_features,
    val_labels
) = build_features(
    val_df,
    "Validation audio"
)

print()
print(
    f"Validation features: "
    f"{len(val_features)}"
)


# ============================================================
# PRECOMPUTE TEST FEATURES
# ============================================================

print()
print("=" * 70)
print("BUILDING RMS-NORMALIZED TEST FEATURES")
print("=" * 70)

(
    test_valid_df,
    test_features,
    test_labels
) = build_features(
    test_df,
    "Test audio"
)

print()
print(
    f"Test features: "
    f"{len(test_features)}"
)


# ============================================================
# DATA LOADERS FROM PRECOMPUTED FEATURES
# ============================================================

class FeatureArrayDataset(Dataset):

    def __init__(
        self,
        features,
        labels
    ):

        self.features = features
        self.labels = labels

    def __len__(self):

        return len(self.labels)

    def __getitem__(self, idx):

        feature = torch.from_numpy(
            self.features[idx]
        ).unsqueeze(0)

        label = torch.tensor(
            self.labels[idx],
            dtype=torch.float32
        )

        return feature, label


val_dataset = FeatureArrayDataset(
    val_features,
    val_labels
)

test_dataset = FeatureArrayDataset(
    test_features,
    test_labels
)

val_loader = DataLoader(
    val_dataset,
    batch_size=BATCH_SIZE,
    shuffle=False,
    num_workers=0,
)

test_loader = DataLoader(
    test_dataset,
    batch_size=BATCH_SIZE,
    shuffle=False,
    num_workers=0,
)


# ============================================================
# PREDICTION
# ============================================================

def predict(
    loader,
    description
):

    all_labels = []
    all_probs = []

    with torch.no_grad():

        progress = tqdm(
            loader,
            desc=description,
            unit="batch",
            dynamic_ncols=True,
        )

        for features, labels in progress:

            features = features.to(
                device,
                non_blocking=True
            )

            logits = model(
                features
            )

            probs = torch.sigmoid(
                logits
            ).view(-1)

            all_probs.extend(
                probs.cpu()
                .numpy()
                .tolist()
            )

            all_labels.extend(
                labels.numpy()
                .tolist()
            )

    return (
        np.asarray(all_labels),
        np.asarray(all_probs)
    )


# ============================================================
# VALIDATION
# ============================================================

print()
print("=" * 70)
print("STEP 1: VALIDATION")
print("=" * 70)

val_labels, val_probs = predict(
    val_loader,
    "Validation inference"
)

val_auc = roc_auc_score(
    val_labels,
    val_probs
)

print()
print(
    f"Validation ROC-AUC: "
    f"{val_auc:.4f}"
)


# ============================================================
# THRESHOLD SELECTION
# ============================================================

best_threshold = 0.50
best_ba = -1
best_f1 = -1

for threshold in np.arange(
    0.05,
    0.951,
    0.01
):

    preds = (
        val_probs >= threshold
    ).astype(int)

    ba = balanced_accuracy_score(
        val_labels,
        preds
    )

    f1 = f1_score(
        val_labels,
        preds,
        zero_division=0
    )

    if (
        ba > best_ba
        or (
            np.isclose(
                ba,
                best_ba
            )
            and f1 > best_f1
        )
    ):

        best_threshold = float(
            threshold
        )

        best_ba = ba
        best_f1 = f1


print(
    f"Selected threshold: "
    f"{best_threshold:.2f}"
)

print(
    f"Validation Balanced Accuracy: "
    f"{best_ba:.4f}"
)

print(
    f"Validation F1: "
    f"{best_f1:.4f}"
)


# ============================================================
# FINAL TEST
# ============================================================

print()
print("=" * 70)
print("STEP 2: RMS-NORMALIZED UNSEEN RTVC TEST")
print("=" * 70)

test_labels, test_probs = predict(
    test_loader,
    "Test inference"
)

test_preds = (
    test_probs >= best_threshold
).astype(int)


# ============================================================
# METRICS
# ============================================================

test_auc = roc_auc_score(
    test_labels,
    test_probs
)

test_accuracy = accuracy_score(
    test_labels,
    test_preds
)

test_ba = balanced_accuracy_score(
    test_labels,
    test_preds
)

test_precision = precision_score(
    test_labels,
    test_preds,
    zero_division=0
)

test_recall = recall_score(
    test_labels,
    test_preds,
    zero_division=0
)

test_f1 = f1_score(
    test_labels,
    test_preds,
    zero_division=0
)

cm = confusion_matrix(
    test_labels,
    test_preds
)


print()
print(
    f"Test ROC-AUC: "
    f"{test_auc:.4f}"
)

print(
    f"Threshold: "
    f"{best_threshold:.2f}"
)

print(
    f"Accuracy: "
    f"{test_accuracy:.4f}"
)

print(
    f"Balanced Accuracy: "
    f"{test_ba:.4f}"
)

print(
    f"Precision: "
    f"{test_precision:.4f}"
)

print(
    f"Recall: "
    f"{test_recall:.4f}"
)

print(
    f"F1: "
    f"{test_f1:.4f}"
)

print()
print("Confusion Matrix:")
print(cm)


# ============================================================
# PROBABILITY SUMMARY
# ============================================================

real_probs = test_probs[
    test_labels == 0
]

fake_probs = test_probs[
    test_labels == 1
]

print()
print("=" * 70)
print("PROBABILITY SUMMARY")
print("=" * 70)

print(
    f"Real mean: "
    f"{real_probs.mean():.6f}"
)

print(
    f"Real median: "
    f"{np.median(real_probs):.6f}"
)

print(
    f"Real min: "
    f"{real_probs.min():.6f}"
)

print(
    f"Real max: "
    f"{real_probs.max():.6f}"
)

print()

print(
    f"Fake mean: "
    f"{fake_probs.mean():.6f}"
)

print(
    f"Fake median: "
    f"{np.median(fake_probs):.6f}"
)

print(
    f"Fake min: "
    f"{fake_probs.min():.6f}"
)

print(
    f"Fake max: "
    f"{fake_probs.max():.6f}"
)


# ============================================================
# METHOD-WISE RESULTS
# ============================================================

print()
print("=" * 70)
print("METHOD-WISE RESULTS")
print("=" * 70)

results = test_valid_df.copy()

results[
    "rms_normalized_fake_probability"
] = test_probs

results[
    "predicted_label"
] = test_preds


for method, group in results.groupby(
    "method"
):

    indices = group.index.to_numpy()

    method_labels = test_labels[
        indices
    ]

    method_probs = test_probs[
        indices
    ]

    method_preds = test_preds[
        indices
    ]

    method_accuracy = accuracy_score(
        method_labels,
        method_preds
    )

    print()
    print(
        f"Method: {method}"
    )

    print(
        f"Samples: {len(group)}"
    )

    print(
        f"Accuracy: "
        f"{method_accuracy:.4f}"
    )

    print(
        f"Mean fake probability: "
        f"{method_probs.mean():.6f}"
    )


# ============================================================
# SAVE
# ============================================================

results.to_csv(
    OUTPUT_CSV,
    index=False
)

print()
print("=" * 70)
print("RESULTS SAVED")
print("=" * 70)

print(OUTPUT_CSV)

print()
print("=" * 70)
print("RMS ROBUSTNESS TEST COMPLETE")
print("=" * 70)